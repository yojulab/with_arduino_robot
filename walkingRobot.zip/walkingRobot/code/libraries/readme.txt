C:\Users\user\Documents\Arduino\libraries

For information on installing libraries, see: http://www.arduino.cc/en/Guide/Libraries
